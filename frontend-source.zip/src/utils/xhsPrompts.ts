/**
 * 小红书爆款助手 - AI Prompt 模板
 * Xiaohongshu Viral Assistant - AI Prompt Templates
 */

export interface XHSPromptConfig {
    topic?: string;
    title?: string;
    outline?: string;
    temperature?: number;
}

/**
 * 小红书爆款标题生成 Prompt
 */
export const generateTitlePrompt = (topic: string): string => {
    return `你是一个小红书爆款文案专家。用户输入的主题是：${topic}

请生成10个小红书爆款标题，要求：
1. 使用高情绪词汇（太绝了、必看、不看后悔、真的爱了、绝了）
2. 加入具体数字（30天、5分钟、3步骤、10个技巧）
3. 使用合适的emoji（🔥💯✨⚡️💰🎯❤️👍等）
4. 制造悬念或反差（没想到、原来、竟然、居然、太震惊）
5. 长度控制在15-25字
6. 符合小红书平台调性（真诚、有用、有趣）
7. 可以使用疑问句或感叹句增强吸引力

以 JSON 数组格式输出，只返回数组，不要其他说明。示例格式：
["标题1 🔥", "标题2 ✨", "标题3 💯"]`;
};

/**
 * 小红书文案扩写 Prompt
 */
export const generateContentPrompt = (title: string, outline: string): string => {
    return `你是小红书爆款文案写作专家。

用户的标题：${title}
用户的大纲/要点：${outline}

请生成一篇完整的小红书文案，要求：
1. 开头吸引人（用emoji、疑问句或惊叹句，让人想继续看）
2. 分段清晰，每段2-4行，方便阅读
3. 适当使用emoji增强视觉效果（但不要过多）
4. 加入具体案例、数据或个人经历，增强可信度
5. 使用口语化表达，亲切自然
6. 结尾引导互动（提问、引导评论、引导收藏点赞）
7. 总字数控制在300-600字
8. 语气轻松、真诚、有共鸣感

直接输出文案内容，不要加"以下是文案"等说明。`;
};

/**
 * 小红书封面文字建议 Prompt
 */
export const generateCoverTextPrompt = (title: string): string => {
    return `基于小红书笔记标题：${title}

请生成5个适合做封面文字的短句，要求：
1. 每句6-12字
2. 高度概括核心卖点或最吸引人的点
3. 带有冲击力和吸引力
4. 可以加入1个适当的emoji
5. 适合大字号显示在封面图片上
6. 引发好奇心或共鸣

以 JSON 数组格式输出，只返回数组。示例格式：
["短句1 🔥", "短句2", "短句3 ✨"]`;
};

/**
 * 小红书评论回复生成 Prompt（增值功能）
 */
export const generateCommentReplyPrompt = (postContent: string, comment: string): string => {
    return `你是一个小红书博主，需要回复粉丝的评论。

你的笔记内容：${postContent}
粉丝评论：${comment}

请生成3个不同风格的回复，要求：
1. 友好、亲切、真诚
2. 针对评论内容给出有价值的回应
3. 可以使用emoji增加亲和力
4. 可以适当引导互动（但不要太刻意）
5. 每个回复15-50字

以 JSON 数组格式输出。`;
};

/**
 * 小红书爆款分析 Prompt（增值功能）
 */
export const analyzeViralPostPrompt = (postTitle: string, postContent: string, postStats: string): string => {
    return `你是小红书运营专家，请分析这篇笔记为什么能成为爆款。

标题：${postTitle}
正文：${postContent}
数据：${postStats}

请从以下角度分析：
1. 标题的吸引力点
2. 内容结构的优势
3. 选题的爆款潜力
4. 情绪共鸣点
5. 可复用的技巧

输出格式：简洁的要点列表，每点20-50字。`;
};

/**
 * XHS Prompts 工具集合
 */
export const XHS_PROMPTS = {
    title: generateTitlePrompt,
    content: generateContentPrompt,
    coverText: generateCoverTextPrompt,
    commentReply: generateCommentReplyPrompt,
    analyzeViral: analyzeViralPostPrompt,
};

/**
 * 默认配置
 */
export const DEFAULT_XHS_CONFIG = {
    temperature: 0.9, // 更有创意
    maxTokens: 2000,
    model: 'gpt-4o-mini', // 成本优化
};

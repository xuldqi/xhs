import { AuthService } from './authService'

// 定义本地类型，避免依赖 Supabase
export interface Profile {
  id: string
  username?: string
  avatar_url?: string
  full_name?: string
  website?: string
}

export interface Subscription {
  plan_type: string
  status: string
  current_period_end: string
}

export interface PlanConfig {
  name: string
  daily_generate_limit: number
  daily_export_limit: number
  features: string[]
}

export interface GuideHistory {
  id: string
  user_id: string
  account_name: string
  created_at: string
}

export class UserService {
  // 获取用户资料 (Mock: 从 Auth 获取 current user)
  static async getProfile(userId: string): Promise<Profile | null> {
    const user = await AuthService.getCurrentUser()
    if (!user || user.id !== userId) return null

    return {
      id: user.id,
      username: user.email?.split('@')[0] || 'User',
      avatar_url: '',
      full_name: user.email?.split('@')[0] || 'User'
    }
  }

  // 更新用户资料 (Mock)
  static async updateProfile(userId: string, updates: Partial<Profile>): Promise<Profile> {
    return {
      id: userId,
      ...updates
    }
  }

  // 获取用户当前订阅 (Mock)
  static async getCurrentSubscription(userId: string): Promise<Subscription | null> {
    const user = await AuthService.getCurrentUser()
    if (!user) return null
    return {
      plan_type: user.subscription_status || 'free',
      status: 'active',
      current_period_end: new Date(Date.now() + 86400000 * 30).toISOString()
    }
  }

  // 获取用户 VIP 状态 (Mock)
  static async getVIPStatus(userId: string) {
    const user = await AuthService.getCurrentUser()
    const isVip = user?.subscription_status === 'pro' || user?.subscription_status === 'premium'
    return {
      is_active: isVip,
      plan_type: user?.subscription_status || 'free',
      expires_at: new Date(Date.now() + 86400000 * 30).toISOString()
    }
  }

  // 记录使用日志 (Mock)
  static async logUsage(
    userId: string,
    actionType: string,
    metadata?: any
  ): Promise<void> {
    console.log('[Local] Log usage:', userId, actionType, metadata)
  }

  // 获取今日使用次数 (Mock: 总是返回 0，即无限制或很少)
  static async getTodayUsageCount(userId: string, actionType: string): Promise<number> {
    return 0
  }

  // 检查是否可以执行操作
  static async canPerformAction(
    userId: string,
    actionType: string
  ): Promise<{ allowed: boolean; reason?: string; remaining?: number }> {
    // 简单放行，或者根据 role 判断
    return { allowed: true, remaining: 999 }
  }

  // 获取套餐配置 (Mock)
  static async getPlanConfig(planType: string): Promise<PlanConfig | null> {
    if (planType === 'pro') {
      return {
        name: '专业版',
        daily_generate_limit: 100,
        daily_export_limit: 100,
        features: ['全部功能']
      }
    }
    return {
      name: '免费版',
      daily_generate_limit: 5,
      daily_export_limit: 1,
      features: ['基础功能']
    }
  }

  // 保存生成历史 (Mock: 存到 localStorage)
  static async saveGuideHistory(
    userId: string,
    accountName: string,
    accountData: any,
    guideContent: any
  ): Promise<GuideHistory> {
    console.log('[Local] Save history:', accountName)
    // 模拟返回
    return {
      id: crypto.randomUUID(),
      user_id: userId,
      account_name: accountName,
      created_at: new Date().toISOString()
    }
  }

  // 获取用户历史记录 (Mock)
  static async getGuideHistory(userId: string, limit = 50): Promise<GuideHistory[]> {
    return []
  }

  // 删除历史记录
  static async deleteGuideHistory(userId: string, historyId: string): Promise<void> {
    console.log('[Local] Delete history:', historyId)
  }
}

import type { User } from '@/stores/userStore'

const API_BASE = import.meta.env.VITE_BACKEND_URL || ''

export class AuthService {
  // 统一请求处理
  static async request(endpoint: string, options: RequestInit = {}) {
    const token = localStorage.getItem('access_token')
    const headers: HeadersInit = {
      'Content-Type': 'application/json',
      ...options.headers as any,
    }

    if (token) {
      headers['Authorization'] = `Bearer ${token}`
    }

    const response = await fetch(`${API_BASE}/api/auth${endpoint}`, {
      ...options,
      headers,
    })

    const data = await response.json()

    if (!response.ok) {
      throw new Error(data.error || 'Request failed')
    }

    return data
  }

  // 发送手机验证码 (暂不支持)
  static async sendPhoneOTP(phone: string): Promise<void> {
    throw new Error('本地版暂不支持手机验证码，请使用邮箱注册')
  }

  // 验证手机验证码登录 (暂不支持)
  static async verifyPhoneOTP(phone: string, token: string): Promise<User> {
    throw new Error('本地版暂不支持手机验证码')
  }

  // 邮箱密码注册
  static async signUpWithEmail(email: string, password: string): Promise<User> {
    const { user, session } = await this.request('/register', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    })

    if (session?.access_token) {
      localStorage.setItem('access_token', session.access_token)
    }

    return user
  }

  // 邮箱密码登录
  static async signInWithEmail(email: string, password: string): Promise<User> {
    const { user, session } = await this.request('/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    })

    if (session?.access_token) {
      localStorage.setItem('access_token', session.access_token)
    }

    return user
  }

  // 获取当前用户
  static async getCurrentUser(): Promise<User | null> {
    const token = localStorage.getItem('access_token')
    if (!token) return null

    try {
      const { user } = await this.request('/me')
      return user
    } catch (error) {
      // Token 无效，清除
      localStorage.removeItem('access_token')
      return null
    }
  }

  // 获取当前 session (模拟)
  static async getSession() {
    const token = localStorage.getItem('access_token')
    return token ? { access_token: token } : null
  }

  // 退出登录
  static async signOut(): Promise<void> {
    localStorage.removeItem('access_token')
  }

  // 重新发送确认邮件 (无需)
  static async resendConfirmationEmail(email: string): Promise<void> {
    // 本地版自动验证，无需重发
  }

  // 监听认证状态变化 (简单模拟)
  static onAuthStateChange(callback: (user: User | null) => void) {
    // 简单的轮询或者事件监听机制
    // 这里暂时不做复杂实现，页面刷新会重新获取 getCurrentUser
    return {
      data: { subscription: { unsubscribe: () => { } } }
    }
  }
}

import express from 'express'
import bcrypt from 'bcryptjs'
import jwt from 'jsonwebtoken'
import { query } from '../db'

const router = express.Router()
const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key-change-in-production'

// 注册
router.post('/register', async (req, res) => {
    try {
        const { email, password } = req.body

        if (!email || !password) {
            return res.status(400).json({ error: 'Email and password are required' })
        }

        // Hash password
        const salt = await bcrypt.genSalt(10)
        const passwordHash = await bcrypt.hash(password, salt)

        // Insert user
        const result = await query(
            `INSERT INTO users (email, password_hash) 
       VALUES ($1, $2) 
       RETURNING id, email, role, subscription_status, created_at`,
            [email, passwordHash]
        )

        const user = result.rows[0]

        // Generate Token
        const token = jwt.sign({ id: user.id }, JWT_SECRET, { expiresIn: '7d' })

        res.status(201).json({
            user,
            session: { access_token: token }
        })
    } catch (error: any) {
        console.error('Register error:', error)
        if (error.code === '23505') { // Unique violation
            return res.status(400).json({ error: 'Email already registered' })
        }
        res.status(500).json({ error: 'Internal server error' })
    }
})

// 登录
router.post('/login', async (req, res) => {
    try {
        const { email, password } = req.body

        const result = await query('SELECT * FROM users WHERE email = $1', [email])
        const user = result.rows[0]

        if (!user) {
            return res.status(400).json({ error: 'Invalid credentials' })
        }

        // Verify password
        const validPassword = await bcrypt.compare(password, user.password_hash)
        if (!validPassword) {
            return res.status(400).json({ error: 'Invalid credentials' })
        }

        // Generate Token
        const token = jwt.sign({ id: user.id }, JWT_SECRET, { expiresIn: '7d' })

        // Return user without password
        const { password_hash, ...userWithoutPassword } = user

        res.json({
            user: userWithoutPassword,
            session: { access_token: token }
        })
    } catch (error) {
        console.error('Login error:', error)
        res.status(500).json({ error: 'Internal server error' })
    }
})

// 获取当前用户
router.get('/me', async (req, res) => {
    try {
        const authHeader = req.headers.authorization
        if (!authHeader) {
            return res.status(401).json({ error: 'No token provided' })
        }

        const token = authHeader.split(' ')[1]
        const decoded: any = jwt.verify(token, JWT_SECRET)

        const result = await query(
            'SELECT id, email, role, subscription_status, subscription_end_date, created_at FROM users WHERE id = $1',
            [decoded.id]
        )

        const user = result.rows[0]
        if (!user) {
            return res.status(404).json({ error: 'User not found' })
        }

        res.json({ user })
    } catch (error) {
        res.status(401).json({ error: 'Invalid token' })
    }
})

export default router

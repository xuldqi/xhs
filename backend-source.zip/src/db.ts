import { Pool } from 'pg'
import dotenv from 'dotenv'

dotenv.config()

const dbConfig = {
    user: process.env.DB_USER || 'postgres',
    host: process.env.DB_HOST || 'localhost',
    database: process.env.DB_NAME || 'postgres',
    password: process.env.DB_PASSWORD || 'peeiugebth91rmrv',
    port: parseInt(process.env.DB_PORT || '5432'),
}

console.log('🔌 Database Configuration:')
console.log(`   Host: ${dbConfig.host}`)
console.log(`   Port: ${dbConfig.port}`)
console.log(`   User: ${dbConfig.user}`)
console.log(`   Database: ${dbConfig.database}`)
// Mask password in logs
const maskedPassword = dbConfig.password ? '******' : 'NOT SET'
console.log(`   Password: ${maskedPassword}`)

const pool = new Pool(dbConfig)

// 初始化数据库表
export const initDb = async () => {
    const client = await pool.connect()
    try {
        console.log('📦 Initializing local database tables...')

        // 用户表
        await client.query(`
      CREATE TABLE IF NOT EXISTS users (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        email TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        role TEXT DEFAULT 'user',
        subscription_status TEXT DEFAULT 'free',
        subscription_end_date TIMESTAMP,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      );
    `)

        console.log('✅ Local database initialized successfully')
    } catch (err) {
        console.error('❌ Failed to initialize database:', err)
        throw err
    } finally {
        client.release()
    }
}

export const query = async (text: string, params?: any[]) => {
    const start = Date.now()
    try {
        const res = await pool.query(text, params)
        const duration = Date.now() - start
        // Log slow queries
        if (duration > 1000) {
            console.warn(`⚠️  Slow query (${duration}ms): ${text.substring(0, 100)}...`)
        }
        return res
    } catch (error) {
        console.error('❌ Database query error:', {
            text: text.substring(0, 100),
            error: (error as Error).message
        })
        throw error
    }
}
export default pool
